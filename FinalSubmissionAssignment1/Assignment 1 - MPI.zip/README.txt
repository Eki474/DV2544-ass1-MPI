TASK 1
/*
 * Compile with:
 * mpicc ./matmulMPI.c -o mm
 * Run with:
 * mpirun -n [Number of cores(This case should be tested with: 1,2,4,8)] ./sor
 */

TASK 2

/*
 * Compile with:
 * mpicc ./sor.c -o sor
 * Run with:
 * mpirun -n [Number of cores(This case should be tested with: 1,2,4,8)] ./sor
 */